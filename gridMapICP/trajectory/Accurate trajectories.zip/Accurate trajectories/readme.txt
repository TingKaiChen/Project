Usage: in Matlab
load('filename')

There are two variables in each .mat file
wallcloud: global map (build by 0801103937)
trajectory: frame step = 5

The relative position and rotation between wallcloud and 
trajectory are determined.